﻿using MySql.Data.MySqlClient;
using System;
using System.Windows.Forms;

namespace Hospital_Project
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {

        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            this.txt_Password.Text = "";
            this.txt_Id.Text = "";
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM hospital.admintable where AdminLoginId=" + this.txt_Id.Text
                        + " and AdminPassword='" + this.txt_Password.Text + "'; ";

            String driver = "datasource=localhost;port=3306;username=root;password=root";
            //String driver = "SERVER=hospitaldatabase.000webhostapp.com;port=3306;DATABASE=id5023796_root;" +
            //   "UID=root;PASSWORD=root@123";

            MySqlConnection con = new MySqlConnection(driver);
            MySqlCommand cmd = new MySqlCommand(query, con);
            MySqlDataReader reader;
            try
            {
                con.Open();
                reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    String name = reader.GetString("AdminName");
                    String n = reader["AdminName"].ToString();
                    MessageBox.Show("n = " + n);
                    AdminForm.NameofAdmin = name;
                    AdminForm af = new AdminForm();
                    this.Hide();
                    af.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Check usernam eand password");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in Login " + ex.ToString());
            }
            con.Close();
        }
    }
}
